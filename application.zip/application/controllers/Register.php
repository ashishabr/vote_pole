<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent::__construct();
		$this->load->model('reg_model');
		/*if($this->session->userdata("user_name") == ''){
			redirect('login');
		}*/
	}
	
	public function index()
	{
		$sessionclr = array('success','error');
		$this->session->unset_userdata($sessionclr);
		if($this->input->post('submit') != ''){
			$this->add_user_data();
		}
		$this->load->view('register_form');
	}
	
	public function add_user_data(){
		$data['user_name'] = $this->input->post('user_name');
		$data['user_email'] = $mail = $this->input->post('user_email');
		$pass = $this->input->post('user_pass');
		$data['user_pass'] = base64_encode($pass);
		$data['dob'] = strtotime($this->input->post('dob'));
		$data['user_gender'] = $this->input->post('user_gender');
		$data['user_phone'] = $this->input->post('user_phone');
		//$data['user_type'] = $this->input->post('user_type');
		
		//$data['user_address'] = $this->input->post('user_address');
		$user = $this->check_user($mail);
		//$img_upload = $this->image_upload();
		//$image = $img_upload['data']['full_path'];
		//$data['user_image'] = $image;
		if($user > 0){
			$session = array('error'=>'User already exists!');
			$this->session->set_userdata($session);
			return false;
		}	
		
		$this->reg_model->add_user($data);
		$session = array('success'=>'User has been created!');
		$this->session->set_userdata($session);
	}
	
	public function image_upload(){
		$path = APPPATH.'../uploads/';
		$config = array(
		'upload_path' => $path,
		'allowed_types' => 'jpg|jpeg|png',
		'max_size' => '2000000',
		'overwrite' => TRUE,
		);
		$this->load->library('upload',$config);
		if($this->upload->do_upload('user_image')){
			return  array('status' => 1 ,'data' => $this->upload->data());
		}else{
			
			return  array('status' => 0 ,'data' => $this->upload->display_errors());
		}
	}
	public function check_user($mail){
		$user = $this->reg_model->check_user($mail);
		return $user;
	}
}
