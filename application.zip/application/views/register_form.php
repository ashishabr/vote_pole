<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Registration Form</title>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
	
	<div class="container">
		<h3>Registration form</h3>
		<form action="<?=base_url('index.php/register'); ?>" method="post" enctype="multipart/form-data">
		<p style="color: #00ff00" id="success_message"></p>
		<p style="color: #ff0000" id="error_message"></p>
		<div class="form-group">
			<label for="user_name">User Name</label>
			<input class="form-control" type="text" required="" name="user_name" id="user_name"/>
		</div>
		<div class="form-group">
			<label for="user_email">Email</label>
			<input class="form-control" type="text" required="" name="user_email" id="user_email"/>
		</div>
		<div class="form-group">
			<label for="user_pass">Password</label>
			<input class="form-control" onblur="check_pass()" type="password" required="" name="user_pass" id="user_pass"/>
		</div>
		<div class="form-group">
			<label for="conf_pass">Confirm Password</label>
			<input class="form-control" onblur="check_pass()" type="password" required="" name="conf_pass" id="conf_pass"/>
		</div>
		<div class="form-group">
			<label for="user_address">DOB</label>
			<input class="form-control" autocomplete="off" type="text" name="dob" id="dob"/>
		</div>
		<div class="form-group">
			
			<label class="form-check-label" for="gender_male"> Male 
			<input class="form-check-input" type="radio" name="user_gender" id="gender_male" value="1"/></label>
			<label class="form-check-label" for="gender_female"> Female 
			<input class="form-check-input" type="radio" name="user_gender" id="gender_female" value="2"/></label>
		</div>
		<div class="form-group">
			<label for="user_phone">Phone Number</label>
			<input class="form-control" type="text" name="user_phone" id="user_phone"/>
		</div>
		
		<input class="btn" name="submit" type="submit" value="submit"/>
		</form>
	</div>
	
	<script>
	$('#success_message').hide();
	$('#error_message').hide();
	<?php if($this->session->userdata('error') != ''){ ?>
		$('#error_message').show();
		$('#error_message').html('<?= $this->session->userdata("error"); ?>');
	<?php } ?>
	<?php if($this->session->userdata('success') != ''){ ?>
		$('#success_message').show();
		$('#success_message').html('<?= $this->session->userdata("success"); ?>');
	<?php } ?>
	
	$('#dob').datepicker({
		'dateFormat' : 'dd/mm/yy',
		'maxDate' : 0,
	});
		function check_pass(){
			var user_pass = $('#user_pass').val();
			var conf_pass = $('#conf_pass').val();
			if(user_pass != conf_pass && conf_pass != '' && user_pass != ''){
				$('#user_pass').val('');
			}
		}
	function ValidateEmail(mail) 
	{
	 if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(myForm.emailAddr.value))
	  {
	    return (true)
	  }
	  $('#error_message').show();
		$('#error_message').html('You have entered an invalid email address!');
	    return (false)
	}

	</script>
	
</body>
</html>