<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-02-26 13:00:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'codeigniter_test' D:\xampp\php7\htdocs\codeigniter_form\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2023-02-26 13:00:49 --> Unable to connect to the database
